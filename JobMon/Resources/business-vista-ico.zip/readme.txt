Business Icons for Vista

Product page:
http://www.vista-style-icons.com/libs/business-vista-icons.htm
